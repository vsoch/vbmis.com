/*
 * MATLAB Compiler: 4.15 (R2011a)
 * Date: Tue Aug 02 21:27:14 2011
 * Arguments: "-B" "macro_default" "-W" "lib:bandpass" "-T" "link:lib" "-d"
 * "C:\Users\vsochat\Documents\Code\matlab\bandpass\deployed\bandpass\src" "-w"
 * "enable:specified_file_mismatch" "-w" "enable:repeated_file" "-w"
 * "enable:switch_ignored" "-w" "enable:missing_lib_sentinel" "-w"
 * "enable:demo_license" "-v"
 * "C:\Users\vsochat\Documents\Code\matlab\bandpass\bandpass_fsl.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\affine.m" "-a"
 * "C:\Users\vsochat\Documents\Code\matlab\bandpass\bandpass.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\bipolar.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\bresenham_line3d.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\collapse_nii_scan.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\expand_nii_scan.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\extra_nii_hdr.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\flip_lr.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\get_nii_frame.m" "-a"
 * "C:\Users\vsochat\Documents\Code\matlab\bandpass\getFiltCoeffs.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\load_nii.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\load_nii_ext.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\load_nii_hdr.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\load_nii_img.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\load_untouch0_nii_hdr.m"
 * "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\load_untouch_header_only.m"
 * "-a" "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\load_untouch_nii.m"
 * "-a" "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\load_untouch_nii_hdr.m"
 * "-a" "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\load_untouch_nii_img.m"
 * "-a" "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\make_ana.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\make_nii.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\mat_into_hdr.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\reslice_nii.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\rri_file_menu.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\rri_orient.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\rri_orient_ui.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\rri_select_file.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\rri_xhair.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\rri_zoom_menu.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\save_nii.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\save_nii_ext.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\save_nii_hdr.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\save_untouch0_nii_hdr.m"
 * "-a" "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\save_untouch_nii.m"
 * "-a" "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\save_untouch_nii_hdr.m"
 * "-a" "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\save_untouch_slice.m"
 * "-a" "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\unxform_nii.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\verify_nii_ext.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\view_nii.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\view_nii_menu.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\xform_nii.m" 
 */

#ifndef __bandpass_h
#define __bandpass_h 1

#if defined(__cplusplus) && !defined(mclmcrrt_h) && defined(__linux__)
#  pragma implementation "mclmcrrt.h"
#endif
#include "mclmcrrt.h"
#ifdef __cplusplus
extern "C" {
#endif

#if defined(__SUNPRO_CC)
/* Solaris shared libraries use __global, rather than mapfiles
 * to define the API exported from a shared library. __global is
 * only necessary when building the library -- files including
 * this header file to use the library do not need the __global
 * declaration; hence the EXPORTING_<library> logic.
 */

#ifdef EXPORTING_bandpass
#define PUBLIC_bandpass_C_API __global
#else
#define PUBLIC_bandpass_C_API /* No import statement needed. */
#endif

#define LIB_bandpass_C_API PUBLIC_bandpass_C_API

#elif defined(_HPUX_SOURCE)

#ifdef EXPORTING_bandpass
#define PUBLIC_bandpass_C_API __declspec(dllexport)
#else
#define PUBLIC_bandpass_C_API __declspec(dllimport)
#endif

#define LIB_bandpass_C_API PUBLIC_bandpass_C_API


#else

#define LIB_bandpass_C_API

#endif

/* This symbol is defined in shared libraries. Define it here
 * (to nothing) in case this isn't a shared library. 
 */
#ifndef LIB_bandpass_C_API 
#define LIB_bandpass_C_API /* No special import/export declaration */
#endif

extern LIB_bandpass_C_API 
bool MW_CALL_CONV bandpassInitializeWithHandlers(
       mclOutputHandlerFcn error_handler, 
       mclOutputHandlerFcn print_handler);

extern LIB_bandpass_C_API 
bool MW_CALL_CONV bandpassInitialize(void);

extern LIB_bandpass_C_API 
void MW_CALL_CONV bandpassTerminate(void);



extern LIB_bandpass_C_API 
void MW_CALL_CONV bandpassPrintStackTrace(void);

extern LIB_bandpass_C_API 
bool MW_CALL_CONV mlxBandpass_fsl(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[]);

extern LIB_bandpass_C_API 
long MW_CALL_CONV bandpassGetMcrID();



extern LIB_bandpass_C_API bool MW_CALL_CONV mlfBandpass_fsl(mxArray* nifti, mxArray* outfile, mxArray* TR, mxArray* fl, mxArray* fh);

#ifdef __cplusplus
}
#endif
#endif
