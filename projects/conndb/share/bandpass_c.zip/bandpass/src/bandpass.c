/*
 * MATLAB Compiler: 4.15 (R2011a)
 * Date: Tue Aug 02 21:27:14 2011
 * Arguments: "-B" "macro_default" "-W" "lib:bandpass" "-T" "link:lib" "-d"
 * "C:\Users\vsochat\Documents\Code\matlab\bandpass\deployed\bandpass\src" "-w"
 * "enable:specified_file_mismatch" "-w" "enable:repeated_file" "-w"
 * "enable:switch_ignored" "-w" "enable:missing_lib_sentinel" "-w"
 * "enable:demo_license" "-v"
 * "C:\Users\vsochat\Documents\Code\matlab\bandpass\bandpass_fsl.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\affine.m" "-a"
 * "C:\Users\vsochat\Documents\Code\matlab\bandpass\bandpass.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\bipolar.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\bresenham_line3d.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\collapse_nii_scan.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\expand_nii_scan.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\extra_nii_hdr.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\flip_lr.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\get_nii_frame.m" "-a"
 * "C:\Users\vsochat\Documents\Code\matlab\bandpass\getFiltCoeffs.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\load_nii.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\load_nii_ext.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\load_nii_hdr.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\load_nii_img.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\load_untouch0_nii_hdr.m"
 * "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\load_untouch_header_only.m"
 * "-a" "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\load_untouch_nii.m"
 * "-a" "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\load_untouch_nii_hdr.m"
 * "-a" "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\load_untouch_nii_img.m"
 * "-a" "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\make_ana.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\make_nii.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\mat_into_hdr.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\reslice_nii.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\rri_file_menu.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\rri_orient.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\rri_orient_ui.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\rri_select_file.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\rri_xhair.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\rri_zoom_menu.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\save_nii.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\save_nii_ext.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\save_nii_hdr.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\save_untouch0_nii_hdr.m"
 * "-a" "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\save_untouch_nii.m"
 * "-a" "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\save_untouch_nii_hdr.m"
 * "-a" "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\save_untouch_slice.m"
 * "-a" "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\unxform_nii.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\verify_nii_ext.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\view_nii.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\view_nii_menu.m" "-a"
 * "C:\Users\vsochat\Documents\MATLAB\NiftiToolbox\xform_nii.m" 
 */

#include <stdio.h>
#define EXPORTING_bandpass 1
#include "bandpass.h"

static HMCRINSTANCE _mcr_inst = NULL;


#if defined( _MSC_VER) || defined(__BORLANDC__) || defined(__WATCOMC__) || defined(__LCC__)
#ifdef __LCC__
#undef EXTERN_C
#endif
#include <windows.h>

static char path_to_dll[_MAX_PATH];

BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, void *pv)
{
    if (dwReason == DLL_PROCESS_ATTACH)
    {
        if (GetModuleFileName(hInstance, path_to_dll, _MAX_PATH) == 0)
            return FALSE;
    }
    else if (dwReason == DLL_PROCESS_DETACH)
    {
    }
    return TRUE;
}
#endif
#ifdef __cplusplus
extern "C" {
#endif

static int mclDefaultPrintHandler(const char *s)
{
  return mclWrite(1 /* stdout */, s, sizeof(char)*strlen(s));
}

#ifdef __cplusplus
} /* End extern "C" block */
#endif

#ifdef __cplusplus
extern "C" {
#endif

static int mclDefaultErrorHandler(const char *s)
{
  int written = 0;
  size_t len = 0;
  len = strlen(s);
  written = mclWrite(2 /* stderr */, s, sizeof(char)*len);
  if (len > 0 && s[ len-1 ] != '\n')
    written += mclWrite(2 /* stderr */, "\n", sizeof(char));
  return written;
}

#ifdef __cplusplus
} /* End extern "C" block */
#endif

/* This symbol is defined in shared libraries. Define it here
 * (to nothing) in case this isn't a shared library. 
 */
#ifndef LIB_bandpass_C_API
#define LIB_bandpass_C_API /* No special import/export declaration */
#endif

LIB_bandpass_C_API 
bool MW_CALL_CONV bandpassInitializeWithHandlers(
    mclOutputHandlerFcn error_handler,
    mclOutputHandlerFcn print_handler)
{
    int bResult = 0;
  if (_mcr_inst != NULL)
    return true;
  if (!mclmcrInitialize())
    return false;
  if (!GetModuleFileName(GetModuleHandle("bandpass"), path_to_dll, _MAX_PATH))
    return false;
    {
        mclCtfStream ctfStream = 
            mclGetEmbeddedCtfStream(path_to_dll, 
                                    1940320);
        if (ctfStream) {
            bResult = mclInitializeComponentInstanceEmbedded(   &_mcr_inst,
                                                                error_handler, 
                                                                print_handler,
                                                                ctfStream, 
                                                                1940320);
            mclDestroyStream(ctfStream);
        } else {
            bResult = 0;
        }
    }  
    if (!bResult)
    return false;
  return true;
}

LIB_bandpass_C_API 
bool MW_CALL_CONV bandpassInitialize(void)
{
  return bandpassInitializeWithHandlers(mclDefaultErrorHandler, mclDefaultPrintHandler);
}

LIB_bandpass_C_API 
void MW_CALL_CONV bandpassTerminate(void)
{
  if (_mcr_inst != NULL)
    mclTerminateInstance(&_mcr_inst);
}

LIB_bandpass_C_API 
long MW_CALL_CONV bandpassGetMcrID() 
{
  return mclGetID(_mcr_inst);
}

LIB_bandpass_C_API 
void MW_CALL_CONV bandpassPrintStackTrace(void) 
{
  char** stackTrace;
  int stackDepth = mclGetStackTrace(&stackTrace);
  int i;
  for(i=0; i<stackDepth; i++)
  {
    mclWrite(2 /* stderr */, stackTrace[i], sizeof(char)*strlen(stackTrace[i]));
    mclWrite(2 /* stderr */, "\n", sizeof(char)*strlen("\n"));
  }
  mclFreeStackTrace(&stackTrace, stackDepth);
}


LIB_bandpass_C_API 
bool MW_CALL_CONV mlxBandpass_fsl(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[])
{
  return mclFeval(_mcr_inst, "bandpass_fsl", nlhs, plhs, nrhs, prhs);
}

LIB_bandpass_C_API 
bool MW_CALL_CONV mlfBandpass_fsl(mxArray* nifti, mxArray* outfile, mxArray* TR, mxArray* 
                                  fl, mxArray* fh)
{
  return mclMlfFeval(_mcr_inst, "bandpass_fsl", 0, 0, 5, nifti, outfile, TR, fl, fh);
}
